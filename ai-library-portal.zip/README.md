# מעבדת הספרייה – פורטל למידת AI (סטטי)

גרסה מוכנה ל-GitHub Pages. אין צורך בבילד.


## פריסה (Deploy)
1. פתח/י ריפו פומבי בגיטהאב.
2. העלה/י את הקבצים שבתיקייה הזו (לפחות `index.html`).
3. Settings → Pages → Source: `main` / Root.
4. קבל/י קישור: `https://USERNAME.github.io/REPO/`.

## הערות
- Tailwind, React ו-Babel נטענים מ-CDN.
- שמירת נתונים ב-localStorage של הדפדפן.
